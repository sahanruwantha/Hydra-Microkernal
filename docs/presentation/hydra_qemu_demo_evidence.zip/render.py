import bisect
import json
import math
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw, ImageFont

out = Path('/home/sahan/.codex/visualizations/2026/10/10/01a1238a-8813-72b1-a31d-acb4174507f3/qemu-recording-20261014')
rows = [json.loads(line) for line in (out / 'qemu-session.cast').read_text().splitlines()]
events = [row for row in rows[1:] if row[1] == 'o']
metadata = json.loads((out / 'capture-metadata.json').read_text())
actions = {row['event']: round(row['time'], 6) for row in metadata['actions']}

class Terminal:
    def __init__(self, width=128, height=34):
        self.width, self.height = width, height
        self.lines = [''] * height
        self.x = self.y = 0

    def feed(self, value):
        for char in value:
            if char == '\r':
                self.x = 0
            elif char == '\n':
                self.y += 1
                if self.y == self.height:
                    self.lines.pop(0)
                    self.lines.append('')
                    self.y -= 1
            elif char == '\x00':
                continue
            else:
                assert ord(char) >= 32, repr(char)
                if self.x == self.width:
                    self.x = 0
                    self.feed('\n')
                line = self.lines[self.y].ljust(self.x)
                self.lines[self.y] = line[:self.x] + char + line[self.x + 1:]
                self.x += 1

check = Terminal(8, 3)
check.feed('abc\rX\n\rtest\x00')
assert check.lines[:2] == ['Xbc', 'test']
check.feed('\n\rone\n\rtwo')
assert check.lines == ['test', 'one', 'two']

terminal = Terminal()
snapshots, times, combined = [], [], ''
markers = {}
for elapsed, _, value in events:
    terminal.feed(value)
    combined += value.replace('\r', '')
    times.append(elapsed)
    snapshots.append((terminal.lines.copy(), terminal.x, terminal.y))
    for name, marker in [('mode', 'Migration mode: USER-SPACE\n'),
                         ('tests', '[main] Entering main loop...\n'),
                         ('sweep', '[main] BENCH_DONE auto_runs=60\n')]:
        if name not in markers and marker in combined:
            markers[name] = elapsed
assert len(markers) == 3

# Holds and slow playback are explicit; the underlying UART text is unchanged.
chapters = [
    {'label': '01 / BOOT', 'start': markers['mode'], 'end': markers['mode'], 'duration': 4, 'playback': 'Paused for reading'},
    {'label': '02 / AUTOMATIC SELF-TESTS', 'start': markers['tests'], 'end': markers['tests'], 'duration': 5, 'playback': 'Paused for reading'},
    {'label': '03 / 60 AUTOMATIC RESTORES COMPLETED', 'start': markers['sweep'], 'end': markers['sweep'], 'duration': 5, 'playback': 'Paused for reading'},
    {'label': '04 / INTERACTIVE CHECKPOINT + RESTORE   [c]', 'start': actions['input_c'] - .1, 'end': actions['interactive_checkpoint_complete'], 'duration': 3, 'playback': 'Slowed for reading'},
    {'label': '04 / INTERACTIVE CHECKPOINT + RESTORE   [c]', 'start': actions['interactive_checkpoint_complete'], 'end': actions['interactive_checkpoint_complete'], 'duration': 7, 'playback': 'Paused for reading'},
    {'label': '05 / CONTROLLED TASK FAILURE + RECOVERY   [r]', 'start': actions['input_r'] - .1, 'end': actions['interactive_recovery_complete'], 'duration': 4, 'playback': 'Slowed for reading'},
    {'label': '05 / CONTROLLED TASK FAILURE + RECOVERY   [r]', 'start': actions['interactive_recovery_complete'], 'end': actions['interactive_recovery_complete'], 'duration': 8, 'playback': 'Paused for reading'},
]
(out / 'video-edit.json').write_text(json.dumps(chapters, indent=2) + '\n')
font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 23)
title_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 29)
small_font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 20)
assert font.getlength('M' * 128) < 1800
fps = 10
video = out / 'hydra_qemu_checkpoint_recovery.mp4'
encoder = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo',
    '-pix_fmt', 'rgb24', '-s', '1920x1080', '-r', str(fps), '-i', '-',
    '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-threads', '2',
    '-pix_fmt', 'yuv420p', '-r', '30', '-movflags', '+faststart', str(video)], stdin=subprocess.PIPE)
try:
    for chapter_index, chapter in enumerate(chapters):
        frames = round(chapter['duration'] * fps)
        for frame_index in range(frames):
            ratio = frame_index / max(1, frames - 1)
            source_time = chapter['start'] + ratio * (chapter['end'] - chapter['start'])
            index = bisect.bisect_right(times, source_time) - 1
            assert index >= 0
            lines, x, y = snapshots[index]
            picture = Image.new('RGB', (1920, 1080), '#0c1219')
            draw = ImageDraw.Draw(picture)
            draw.text((42, 22), 'Hydra / QEMU terminal recording', font=title_font, fill='#f3f7fa')
            draw.text((43, 67), chapter['label'], font=small_font, fill='#85c9ed')
            draw.rounded_rectangle((39, 111, 1881, 1018), radius=9, fill='#111b25', outline='#304253', width=2)
            for line_index, line in enumerate(lines):
                color = '#a9bfd2' if line.startswith('BENCH') else '#e0e7ee'
                if 'PASS:' in line:
                    color = '#82d8a4'
                draw.text((59, 122 + line_index * 26), line, font=font, fill=color)
            draw.text((43, 1035), 'Actual UART replay / edited with pauses / desktop not captured', font=small_font, fill='#a9b9c8')
            right = f"Capture {source_time:06.2f}s / {chapter['playback']}"
            draw.text((1880, 1035), right, anchor='ra', font=small_font, fill='#a9b9c8')
            encoder.stdin.write(picture.tobytes())
            if frame_index == frames - 1:
                picture.save(out / f'preview-{chapter_index + 1}.png')
        print(f"Rendered {chapter['label']}", flush=True)
finally:
    encoder.stdin.close()
assert encoder.wait() == 0
print(f'Exported {sum(c["duration"] for c in chapters)}-second video: {video}', flush=True)

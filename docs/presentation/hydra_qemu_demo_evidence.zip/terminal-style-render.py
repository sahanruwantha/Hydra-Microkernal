import bisect
import json
import math
from pathlib import Path
import subprocess
from PIL import Image, ImageDraw, ImageFont

out = Path(__file__).resolve().parent
rows = [json.loads(line) for line in (out / 'qemu-session.cast').read_text().splitlines()]
events = [row for row in rows[1:] if row[1] == 'o']
metadata = json.loads((out / 'capture-metadata.json').read_text())
actions = {row['event']: round(row['time'], 6) for row in metadata['actions']}

class Terminal:
    def __init__(self, width=128, height=34):
        self.width, self.height = width, height
        self.lines = [''] * height
        self.x = self.y = 0

    def feed(self, value):
        for char in value:
            if char == '\r':
                self.x = 0
            elif char == '\n':
                self.y += 1
                if self.y == self.height:
                    self.lines.pop(0)
                    self.lines.append('')
                    self.y -= 1
            elif char == '\x00':
                continue
            else:
                assert ord(char) >= 32, repr(char)
                if self.x == self.width:
                    self.x = 0
                    self.feed('\n')
                line = self.lines[self.y].ljust(self.x)
                self.lines[self.y] = line[:self.x] + char + line[self.x + 1:]
                self.x += 1

check = Terminal(8, 3)
check.feed('abc\rX\n\rtest\x00')
assert check.lines[:2] == ['Xbc', 'test']
check.feed('\n\rone\n\rtwo')
assert check.lines == ['test', 'one', 'two']

terminal = Terminal()
snapshots, times, combined = [], [], ''
markers = {}
for elapsed, _, value in events:
    terminal.feed(value)
    combined += value.replace('\r', '')
    times.append(elapsed)
    snapshots.append((terminal.lines.copy(), terminal.x, terminal.y))
    for name, marker in [('mode', 'Migration mode: USER-SPACE\n'),
                         ('tests', '[main] Entering main loop...\n'),
                         ('sweep', '[main] BENCH_DONE auto_runs=60\n')]:
        if name not in markers and marker in combined:
            markers[name] = elapsed
assert len(markers) == 3

# Holds and slow playback are explicit; the underlying UART text is unchanged.
chapters = [
    {'label': '01 / BOOT', 'start': markers['mode'], 'end': markers['mode'], 'duration': 4, 'playback': 'Paused for reading'},
    {'label': '02 / AUTOMATIC SELF-TESTS', 'start': markers['tests'], 'end': markers['tests'], 'duration': 5, 'playback': 'Paused for reading'},
    {'label': '03 / 60 AUTOMATIC RESTORES COMPLETED', 'start': markers['sweep'], 'end': markers['sweep'], 'duration': 5, 'playback': 'Paused for reading'},
    {'label': '04 / INTERACTIVE CHECKPOINT + RESTORE   [c]', 'start': actions['input_c'] - .1, 'end': actions['interactive_checkpoint_complete'], 'duration': 3, 'playback': 'Slowed for reading'},
    {'label': '04 / INTERACTIVE CHECKPOINT + RESTORE   [c]', 'start': actions['interactive_checkpoint_complete'], 'end': actions['interactive_checkpoint_complete'], 'duration': 7, 'playback': 'Paused for reading'},
    {'label': '05 / CONTROLLED TASK FAILURE + RECOVERY   [r]', 'start': actions['input_r'] - .1, 'end': actions['interactive_recovery_complete'], 'duration': 4, 'playback': 'Slowed for reading'},
    {'label': '05 / CONTROLLED TASK FAILURE + RECOVERY   [r]', 'start': actions['interactive_recovery_complete'], 'end': actions['interactive_recovery_complete'], 'duration': 8, 'playback': 'Paused for reading'},
]
(out / 'video-edit.json').write_text(json.dumps(chapters, indent=2) + '\n')
font_path = '/usr/share/fonts/truetype/ubuntu/UbuntuMono[wght].ttf'
sans_path = '/usr/share/fonts/truetype/ubuntu/Ubuntu[wdth,wght].ttf'
label_font = ImageFont.truetype(sans_path, 28)
title_font = ImageFont.truetype(sans_path, 23)
small_font = ImageFont.truetype(sans_path, 20)

def window(lines, size=(1920, 1080), origin=(0, 0), width=1920, font_size=28, line_height=28):
    picture = Image.new('RGB', size, '#ffffff')
    draw = ImageDraw.Draw(picture)
    left, top = origin
    height = 58 + 22 + line_height * 34
    if origin == (0, 0):
        height = size[1] - 1
    draw.rectangle((left, top, left + width - 1, top + height), fill='#300a24')
    draw.rectangle((left, top, left + width - 1, top + 58), fill='#292929')
    draw.text((left + width / 2, top + 29), 'Hydra-Microkernal — QEMU', anchor='mm', font=title_font, fill='#eeeeee')
    draw.rounded_rectangle((left + 12, top + 10, left + 52, top + 48), radius=5, outline='#555555')
    draw.line((left + 25, top + 29, left + 39, top + 29), fill='#eeeeee', width=2)
    draw.line((left + 32, top + 22, left + 32, top + 36), fill='#eeeeee', width=2)
    # Familiar terminal window controls; these are presentation chrome.
    draw.line((left + width - 107, top + 34, left + width - 95, top + 34), fill='#cccccc', width=2)
    draw.rectangle((left + width - 75, top + 23, left + width - 63, top + 35), outline='#cccccc', width=2)
    draw.line((left + width - 40, top + 23, left + width - 28, top + 35), fill='#cccccc', width=2)
    draw.line((left + width - 40, top + 35, left + width - 28, top + 23), fill='#cccccc', width=2)
    mono = ImageFont.truetype(font_path, font_size)
    assert max(mono.getlength(line) for line in lines) + 38 < width
    for i, line in enumerate(lines):
        draw.text((left + 18, top + 71 + i * line_height), line, font=mono, fill='#eeeeec')
    return picture, mono

def snapshot(t):
    index = bisect.bisect_right(times, t) - 1
    assert index >= 0
    return snapshots[index][0]

def annotated(name, lines, notes):
    picture, mono = window(lines, origin=(20, 88), width=1465, font_size=22, line_height=25)
    draw = ImageDraw.Draw(picture)
    draw.text((26, 29), name, font=ImageFont.truetype(sans_path, 36), fill='#252525')
    for marker, label, box_y in notes:
        matches = [i for i, line in enumerate(lines) if marker in line]
        assert len(matches) == 1, (marker, matches)
        row = matches[0]
        y = 88 + 71 + row * 25
        line = lines[row]
        right = 38 + mono.getlength(line) + 9
        draw.rounded_rectangle((32, y - 1, right, y + 24), radius=3, outline='#ec5b36', width=3)
        draw.rounded_rectangle((1525, box_y, 1895, box_y + 91), radius=9, fill='#fff3e6', outline='#e96536', width=2)
        draw.multiline_text((1545, box_y + 14), label, font=label_font, fill='#4a261c', spacing=3)
        end = (right + 6, y + 12)
        start = (1525, box_y + 45)
        mid = (1499, y + 12)
        draw.line([start, mid, end], fill='#ec5b36', width=4)
        draw.polygon([(end[0], end[1]), (end[0] + 13, end[1] - 8), (end[0] + 13, end[1] + 8)], fill='#ec5b36')
    draw.text((26, 1044), 'Actual QEMU output. Terminal appearance recreated; arrows are explanatory annotations.', font=small_font, fill='#555555')
    return picture

checkpoint = snapshot(actions['interactive_checkpoint_complete'])
recovery = snapshot(actions['interactive_recovery_complete'])
assert any('checkpoint OK, 8784 bytes written' in line for line in checkpoint)
assert any('counter=2370 (delta=20)' in line for line in checkpoint)
assert any('post-recovery counter=88 (delta from fault=29)' in line for line in recovery)
screens = [
    ('03_checkpoint_restore', checkpoint, 'Local checkpoint and restore', [
        ('checkpoint OK,', 'Checkpoint captured\n8,784 bytes', 205),
        ('restore OK,', 'Restored task\ngets a new PID', 535),
        ('after restore,', 'Counter advances\nafter restore', 685),
        ('PASS: restored task', 'Restored task\nis running', 830)]),
    ('04_fault_recovery', recovery, 'Controlled task failure and recovery', [
        ('Step 3:', 'Save a checkpoint\nbefore the fault', 260),
        ('Step 5:', 'Kill the task\nto simulate a fault', 510),
        ('Step 6:', 'Counter stays frozen\nwhile task is stopped', 640),
        ('Step 8:', 'Counter advances\nafter recovery', 780),
        ('PASS: workload recovered', 'Recovery verified\nby the test', 915)])
]
for stem, lines, title, notes in screens:
    plain, _ = window(lines)
    plain.save(out / (stem + '_clean.png'))
    annotated(title, lines, notes).save(out / (stem + '_annotated.png'))
    print('Created clean and annotated terminal views:', stem, flush=True)

fps = 10
video = out / 'hydra_qemu_checkpoint_recovery.mp4'
encoder = subprocess.Popen(['ffmpeg', '-y', '-v', 'error', '-f', 'rawvideo',
    '-pix_fmt', 'rgb24', '-s', '1920x1080', '-r', str(fps), '-i', '-',
    '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20', '-threads', '2',
    '-pix_fmt', 'yuv420p', '-r', '30', '-movflags', '+faststart', str(video)], stdin=subprocess.PIPE)
try:
    for chapter_index, chapter in enumerate(chapters):
        frames = round(chapter['duration'] * fps)
        for frame_index in range(frames):
            ratio = frame_index / max(1, frames - 1)
            source_time = chapter['start'] + ratio * (chapter['end'] - chapter['start'])
            picture, _ = window(snapshot(source_time))
            draw = ImageDraw.Draw(picture)
            draw.rectangle((0, 1039, 1919, 1079), fill='#222222')
            draw.text((18, 1048), 'QEMU UART replay  |  ' + chapter['playback'], font=small_font, fill='#bbbbbb')
            draw.text((1902, 1048), f'Source time {source_time:.2f}s', anchor='ra', font=small_font, fill='#bbbbbb')
            encoder.stdin.write(picture.tobytes())
            if frame_index == frames - 1:
                picture.save(out / f'terminal-preview-{chapter_index + 1}.png')
        print('Rendered terminal view:', chapter['label'], flush=True)
finally:
    encoder.stdin.close()
assert encoder.wait() == 0
print('Revised 36-second terminal video exported.', flush=True)

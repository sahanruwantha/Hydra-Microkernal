Hydra QEMU terminal demonstration — 14 October 2026

hydra_qemu_checkpoint_recovery.mp4: 36-second edited presentation replay,
now styled as an Ubuntu terminal window.
03_checkpoint_restore_clean.png / 04_fault_recovery_clean.png: clean views.
03_checkpoint_restore_annotated.png / 04_fault_recovery_annotated.png:
separate arrow/highlight versions for presentation slides.
presentation-format.json: appearance and snapshot provenance.
terminal-style-render.py: the renderer used for these revised exports.
qemu-session.cast: original timestamped output and input (asciicast v2).
qemu-uart.log: original raw UART byte stream.
qemu-uart-readable.txt: the same output with CR and NUL removed.
capture-metadata.json: actual command, actions, exit code, checks, build hash,
source revision and local working-tree identity at capture time.
current-source.patch: runtime source changes required with that base revision.
video-edit.json: source intervals and explicit playback holds/slowing.
capture.py and render.py: the one-off capture and rendering tools used.

This records actual QEMU output and real serial input, then renders terminal
replay frames. No desktop screen was captured. The terminal window appearance is recreated;
the actual recorded QEMU text, PIDs, counters and timestamps are unchanged. The MP4 cuts repeated sweep
output and idle time, and holds or slows successful portions for reading.
The complete original timeline remains in qemu-session.cast.

Verified in the recorded session: scheduler, allocator, user isolation,
malformed-checkpoint rejection, 61 local restores (60 automatic + input c),
and two controlled task-failure recoveries (automatic + input r). QEMU exited
with Ctrl+A then X and exit status 0. Single-node peer discovery warnings are
expected because no peer is attached; this video demonstrates local recovery.
The local test's send/receive tags are placeholders, not network transfer.
Both historical invocation-path comparison tasks execute in supervisor mode.
This functional capture does not replace the report's historical measurements.

For independent replay, open the .cast with an asciicast-compatible player.
For source reproduction, start at the recorded base commit and apply
current-source.patch; use the recorded build configuration and QEMU command.
The one-off scripts use absolute paths. Adjust their output directory to a
new empty directory before recapturing. capture.py asserts exact success
counts and checks for failure markers; render.py only reads that recording.

The initial UART-input failure is retained separately in
build/presentation-capture/uart-input-before-fix/ and is not packaged as a
successful demonstration. Source changes and demonstration assets are local.

To reproduce the revised terminal views, place terminal-style-render.py next
to qemu-session.cast and capture-metadata.json, then run it with Python 3,
Pillow, the Ubuntu fonts and FFmpeg installed. Its parser rejects unsupported
control bytes, checks selected evidence lines and verifies text fits the view.

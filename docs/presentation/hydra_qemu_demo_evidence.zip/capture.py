import codecs
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shlex
import struct
import subprocess
import termios
import time
import tty
from datetime import datetime, timezone

root = Path('/home/sahan/Hydra-Microkernal')
out = Path('/home/sahan/.codex/visualizations/2026/10/10/01a1238a-8813-72b1-a31d-acb4174507f3/qemu-recording-20261014')
out.mkdir(exist_ok=False)
subprocess.run(['make', '-s', 'MIGRATION_MODE=USERSPACE'], cwd=root, check=True)
command = ['qemu-system-riscv64', '-machine', 'virt', '-nographic',
           '-kernel', 'build/kernel.elf', '-global', 'virtio-mmio.force-legacy=false',
           '-netdev', 'user,id=net0', '-device', 'virtio-net-device,netdev=net0']
master, slave = pty.openpty()
tty.setraw(slave)
fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 34, 128, 0, 0))
started = time.monotonic()
process = subprocess.Popen(command, cwd=root, stdin=slave, stdout=slave, stderr=slave,
                           start_new_session=True)
os.close(slave)
decoder = codecs.getincrementaldecoder('utf-8')(errors='replace')
transcript = ''
actions = []
stage = 'automatic'
due = None
header = {'version': 2, 'width': 128, 'height': 34, 'timestamp': int(time.time()),
          'title': 'Hydra: actual QEMU serial terminal session',
          'env': {'TERM': 'vt100'}, 'command': shlex.join(command)}
try:
    with (out / 'qemu-session.cast').open('w') as cast, (out / 'qemu-uart.log').open('wb') as raw:
        cast.write(json.dumps(header) + '\n')
        while time.monotonic() - started < 120:
            elapsed = time.monotonic() - started
            ready, _, _ = select.select([master], [], [], 0.05)
            if ready:
                try:
                    chunk = os.read(master, 65536)
                except OSError as error:
                    if error.errno != errno.EIO:
                        raise
                    chunk = b''
                if not chunk:
                    break
                raw.write(chunk)
                raw.flush()
                text = decoder.decode(chunk)
                transcript += text
                cast.write(json.dumps([round(elapsed, 6), 'o', text], ensure_ascii=False) + '\n')
                cast.flush()
            if stage == 'automatic' and '[fdemo] === Demonstration complete ===' in transcript:
                assert '[main] BENCH_DONE auto_runs=60' in transcript
                assert transcript.count('[migtest] PASS: restored task is running') == 60
                actions.append({'event': 'automatic_checks_complete', 'time': elapsed})
                print(f'Automatic 60-run sweep and recovery finished at {elapsed:.1f}s.', flush=True)
                stage, due = 'wait_c', elapsed + 5
            if stage == 'wait_c' and elapsed >= due:
                os.write(master, b'c')
                cast.write(json.dumps([round(elapsed, 6), 'i', 'c']) + '\n')
                actions.append({'event': 'input_c', 'time': elapsed})
                stage = 'checkpoint'
                print('Sent c to the QEMU UART: recording an additional checkpoint/restore.', flush=True)
            if stage == 'checkpoint' and transcript.count('[migtest] Local migration self-test complete') == 61:
                actions.append({'event': 'interactive_checkpoint_complete', 'time': elapsed})
                stage, due = 'wait_r', elapsed + 7
            if stage == 'wait_r' and elapsed >= due:
                os.write(master, b'r')
                cast.write(json.dumps([round(elapsed, 6), 'i', 'r']) + '\n')
                actions.append({'event': 'input_r', 'time': elapsed})
                stage = 'recovery'
                print('Sent r to the QEMU UART: recording task failure and recovery.', flush=True)
            if stage == 'recovery' and transcript.count('[fdemo] === Demonstration complete ===') == 2:
                actions.append({'event': 'interactive_recovery_complete', 'time': elapsed})
                stage, due = 'wait_exit', elapsed + 9
            if stage == 'wait_exit' and elapsed >= due:
                os.write(master, b'\x01x')
                cast.write(json.dumps([round(elapsed, 6), 'i', '\x01x']) + '\n')
                actions.append({'event': 'exit_qemu', 'time': elapsed})
                stage = 'exit'
        process.wait(timeout=5)
    assert stage == 'exit', (stage, transcript[-3000:])
    assert process.returncode == 0, process.returncode
    assert transcript.count('[migtest] PASS: restored task is running') == 61
    assert transcript.count('[fdemo] PASS: workload recovered from simulated fault') == 2
    for marker in ('[schedtest] PASS:', '[mmtest] PASS:', '[isotest] PASS:',
                   '[migtest] PASS: malformed checkpoint rejected'):
        assert marker in transcript, marker
    for marker in ('FAIL', 'FATAL', 'Unhandled trap', 'Recursive trap',
                   'WARN: counter did not advance', 'WARN: workload did not advance'):
        assert marker not in transcript, marker
    (out / 'qemu-uart-readable.txt').write_text(transcript.replace('\r', '').replace('\x00', ''))
    metadata = {
        'captured_at': datetime.now(timezone.utc).isoformat(),
        'command': command, 'duration': time.monotonic() - started,
        'exit_code': process.returncode, 'actions': actions,
        'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root).decode().strip(),
        'working_tree': subprocess.check_output(['git', 'status', '--short'], cwd=root).decode(),
        'qemu_version': subprocess.check_output(['qemu-system-riscv64', '--version']).decode(),
        'build_config': (root / 'build/.build-config').read_text(),
        'kernel_sha256': hashlib.sha256((root / 'build/kernel.elf').read_bytes()).hexdigest(),
        'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()},
        'validation': {'local_restores': 61, 'recovery_passes': 2,
                       'scheduler': 'PASS', 'allocator': 'PASS', 'isolation': 'PASS',
                       'malformed_checkpoint': 'PASS', 'unexpected_errors': 0},
        'scope': 'Actual QEMU PTY output and input with monotonic timestamps. No desktop pixels captured.'
    }
    (out / 'capture-metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    patch = subprocess.check_output(['git', 'diff', '--', 'apps', 'kernel', 'lib', 'server', 'boot', 'Makefile'], cwd=root)
    (out / 'current-source.patch').write_bytes(patch)
    print(f'Verified actual QEMU recording saved to {out}', flush=True)
finally:
    if process.poll() is None:
        process.terminate()
        process.wait(timeout=5)
    os.close(master)

# Terminal evidence for the two presentation images

These are terminal images rendered from actual executed commands and their
captured output. They are not desktop screen captures or generated test data.
The complete command transcripts include exit codes and are provided beside
the images.

| Presentation image | Terminal evidence | Full command transcript |
|---|---|---|
| [Two invocation paths](../report/figures/figure-5-3.png) | [Both modes executing](01_both_call_paths.png) | [Commands and output](01_both_call_paths.txt) |
| [Latency versus payload size](../report/figures/figure-4-2.png) | [Historical measurement analysis](02_historical_performance.png) | [Commands and output](02_historical_performance.txt) |

## What the first image demonstrates

The current KERNEL and USERSPACE builds were each booted in QEMU. Each
completed the automatic 60-run local checkpoint/restore sweep. The image
shows the selected mode, `BENCH_DONE auto_runs=60`, the restored-task PASS
count, and the actual direct/wrapper calls in `apps/migration_test.c`.
Scheduler, isolation, malformed-record rejection and fault recovery markers
were also checked in the full logs before exporting the image.

Both comparison call paths run in supervisor mode. These functional checks
do not measure a hardware-enforced user/kernel transition.

The capture uses `timeout 60s` to stop QEMU after the experiment. Exit 124 is
the expected timeout termination, not the experiment's pass criterion; the
completion markers, exact restore count and absence of failures are checked
separately.

## What the second image demonstrates

The analysis reads the retained `bench/results/KERNEL.log` and
`bench/results/USERSPACE.log` files behind the existing report chart. It shows
15 observations per extra-payload size and 60 per mode, the per-size means,
and the pooled phase comparison. The complete analysis also reports pooled
phase confidence intervals. The chart's per-size error bars are calculated
by `bench/plot.py` from each size bucket using the same `ci95` helper.

The `bytes` column is extra synthetic payload: 0, 4,096, 16,384 and 65,536.
The chart adds the approximately 8 KB stack, giving approximate state-size
labels of 8, 12, 24 and 72 KB. Similar means and overlapping separate mean
confidence intervals do not prove equivalence.

These are historical observations, separate from the fresh functional tests
in the first image. No historical data or report figures were modified.

## Audit and reproduction

Raw current logs, full historical analysis, command records and SHA-256
metadata are saved under `build/presentation-capture/`. `make clean` removes
that folder. The evidence archive in that folder contains the two images,
their transcripts, raw successful logs, metadata and the current source patch.

A scheduler self-test initially reported `pass=1 elapsed=10 ms` because it
used serviced timer ticks as elapsed time. The test now measures time using
the same 10 MHz `rdtime` source as the stress loop and also requires a timer
interrupt while the register-test task runs. The initial failed capture is
retained separately as `failed-USERSPACE-first.log`; it is not presented as a
passing result. The exported images use fresh successful runs after the fix.

The source revision and local changes are recorded in the metadata and source
patch. The source patch must accompany the base revision when reproducing
these current tests. Host-sensitive QEMU cycle counts can vary between runs.
